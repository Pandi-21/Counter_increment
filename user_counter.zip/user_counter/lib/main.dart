import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart'; // ✅ For Web storage

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginPage(),
    );
  }
}

class DatabaseHelper {
  static Database? _database;

  Future<Database?> get database async {
    if (kIsWeb) return null; // ✅ No SQLite for Web, use SharedPreferences
    if (_database != null) return _database!;
    _database = await _initDB();
    return _database!;
  }

  Future<Database> _initDB() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, 'users.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute(
            'CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, counter INTEGER)');
      },
    );
  }

  Future<int> getCounter(String username) async {
    if (kIsWeb) {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getInt(username) ?? 0;
    }

    final db = await database;
    if (db == null) return 0;

    List<Map<String, dynamic>> result = await db.query(
      'users',
      where: 'username = ?',
      whereArgs: [username],
    );

    if (result.isNotEmpty) {
      return result.first['counter'] ?? 0;
    } else {
      await db.insert('users', {'username': username, 'counter': 0});
      return 0;
    }
  }

  Future<void> updateCounter(String username, int counter) async {
    if (kIsWeb) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(username, counter);
      return;
    }

    final db = await database;
    if (db == null) return;

    await db.update(
      'users',
      {'counter': counter},
      where: 'username = ?',
      whereArgs: [username],
    );
  }
}

class LoginPage extends StatelessWidget {
  final TextEditingController _controller = TextEditingController();
  final DatabaseHelper dbHelper = DatabaseHelper();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [  // ✅ Correctly opened list
              TextField(
                controller: _controller,
                decoration: InputDecoration(labelText: 'Enter Username'),
              ),
              SizedBox(height: 20),  // ✅ Added missing comma
              ElevatedButton(
                onPressed: () async {
                  String username = _controller.text.trim();
                  if (username.isNotEmpty) {
                    int counter = await dbHelper.getCounter(username);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => CounterPage(username: username, counter: counter),
                      ),
                    );
                  }
                },
                child: Text('Login'),
              ),
            ],  // ✅ Correctly closed list
          ),
        ),
      ),
    );
  }
}

class CounterPage extends StatefulWidget {
  final String username;
  final int counter;

  CounterPage({required this.username, required this.counter});

  @override
  _CounterPageState createState() => _CounterPageState();
}

class _CounterPageState extends State<CounterPage> {
  late int _counter;
  final DatabaseHelper dbHelper = DatabaseHelper();

  @override
  void initState() {
    super.initState();
    _counter = widget.counter;
  }

  void _incrementCounter() async {
    setState(() {
      _counter++;
    });
    await dbHelper.updateCounter(widget.username, _counter);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Counter for ${widget.username}')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Counter Value: $_counter', style: TextStyle(fontSize: 24)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _incrementCounter,
              child: Text('Increment'),
            ),
          ],
        ),
      ),
    );
  }
}

